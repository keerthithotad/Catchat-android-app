package com.hfad.catcat.ui.draft;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class DraftsViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public DraftsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is drafts fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }  // Implement the ViewModel
}

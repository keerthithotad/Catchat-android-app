package com.hfad.catcat.ui.trash;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class TrashViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public TrashViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is trash fragment");
    }

    public LiveData<String> getText() {
        return mText;
    } // TODO: Implement the ViewModel
}

package com.hfad.catcat.ui.sent;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class SentViewModel extends ViewModel {

        private MutableLiveData<String> mText;

        public SentViewModel() {
            mText = new MutableLiveData<>();
            mText.setValue("This is sent fragment");
        }

        public LiveData<String> getText() {
            return mText;
        }
}

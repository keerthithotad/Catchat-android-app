package com.hfad.catcat.ui.tool;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class ToolViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public ToolViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is tool fragment");
    }

    public LiveData<String> getText() {
        return mText;
    } // TODO: Implement the ViewModel
}
